
Acne - v1 acne dataset
==============================

This dataset was exported via roboflow.ai on April 25, 2021 at 4:30 PM GMT

It includes 194 images.
Acne are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


